package com.code;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/Logout")
public class LogoutServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	 protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	     PrintWriter out=response.getWriter();   
		 HttpSession session = request.getSession(false);
	            session.invalidate();
	            out.print("<body style=\"background: url(img/img.jpg); background-size: cover; background-attachment: fixed;\">");
				out.println("<div align=center><font color = deep-orange darken-4 size=12>You have Sucessfully Logged Out<br></div>");
				out.println("<div align=center><a href = Login.jsp>Login..</a></div>");
				
	     	 }        
}
