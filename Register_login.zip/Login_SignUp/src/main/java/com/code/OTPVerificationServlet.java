package com.code;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;


@WebServlet("/OtpVerify")
public class OTPVerificationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			  PrintWriter out = response.getWriter();
			  HttpSession session = request.getSession();
			   int userotp = Integer.parseInt(request.getParameter("userotp"));
			  int otp = 552320;
		        if (userotp == otp) {
		            session.setAttribute("authenticated", true);
		            response.sendRedirect("Welcome");
		        } 
		        else {
		        	out.print("<body style=\"background: url(img/img.jpg); background-size: cover; background-attachment: fixed;\">");
					out.println("<div align=center><font color = deep-orange darken-4 size=12>Incorrect OTP. Please try again.<br></div>");
					out.println("<div align=center><font color = deep-orange darken-4 size=12>Login Failed !!!<br></div>");
					out.println("<div align=center><a href = Otp.jsp>Try Again...</a></div>");
		            
//		            request.getRequestDispatcher("Otp.jsp").forward(request, response);
//		            request.setAttribute("message", "Incorrect OTP. Please try again.");
		        } 
		} 
}

		 

