package com.code;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html");  
		PrintWriter out = response.getWriter();

		String n = request.getParameter("Name");
		String e = request.getParameter("Email");
		String u = request.getParameter("UserID");
		String p = request.getParameter("Password");

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/register";
			String username = "root";
			String password = "Kaushik@1999";

			Connection con = DriverManager.getConnection(url, username, password);

			PreparedStatement ps = con.prepareStatement("insert into user(Name,Email,UserID,Password) values(?,?,?,?)");

			ps.setString(1, n);
			ps.setString(2, e);
			ps.setString(3, u);
			ps.setString(4, p);

			ps.executeUpdate();
			out.print("<body style=\"background: url(img/img.jpg); background-size: cover; background-attachment: fixed;\">");
			out.print("<div align= center><font color =green darken-4 size=10>YOU ARE SUCESSFULLY REGISTERED...<a href=Login.jsp>Login</a></div>");
			

		} catch (Exception e2) {
			System.out.println(e2);
		}

		out.close();
	}
}
