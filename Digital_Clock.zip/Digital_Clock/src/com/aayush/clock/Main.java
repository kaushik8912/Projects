package com.aayush.clock;

public class Main {

	public static void main(String[] args) {
		MyWindow clock = new MyWindow();

	}

}
